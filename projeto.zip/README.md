Brasil Soluções DTC Lab 3.0 - DTC + offsets + metadados + pesquisa online.
