let currentFile=null,currentReport=null;const $=id=>document.getElementById(id);
async function initActivation(){const o=$("activationOverlay"),h=$("hwidInput"),m=$("activationMsg"),s=await window.dtcLab.activationStatus();h.value=s.hwid;if(s.activated){o.style.display="none";return}o.style.display="flex";if(s.reason)m.textContent=s.reason;$("copyHwidBtn").onclick=async()=>{await navigator.clipboard.writeText(h.value);m.textContent="HWID copiado."};$("activateBtn").onclick=async()=>{m.textContent="Validando...";const r=await window.dtcLab.activateLicense({serial:$("serialInput").value.trim(),licensedTo:$("licensedToInput").value.trim()});if(r.ok){m.textContent="Ativado.";setTimeout(()=>location.reload(),700)}else m.textContent=r.reason||"Serial inválido."};$("localResetBtn").onclick=async()=>{if(confirm("Apagar ativação local?")){await window.dtcLab.resetActivation();location.reload()}}}document.addEventListener("DOMContentLoaded",initActivation);
$("openBtn").onclick=async()=>{currentFile=await window.dtcLab.openEcuFile();if(!currentFile)return;$("fileInfo").innerHTML=`<p><b>Nome:</b> ${e(currentFile.fileName)}</p><p><b>Tamanho:</b> ${currentFile.size.toLocaleString("pt-BR")} bytes</p><p><b>Tipo:</b> ${e(currentFile.classification?.type)}</p><p><b>Memória:</b> ${e(currentFile.classification?.memory)}</p><p><b>Entropia:</b> ${e(currentFile.classification?.entropy)}</p><p><b>SHA256:</b><br><small>${e(currentFile.classification?.sha256)}</small></p>`;$("hexPreview").textContent=currentFile.previewHex||"---";$("analyzeBtn").disabled=false;$("saveCopyBtn").disabled=false};
$("analyzeBtn").onclick=async()=>{
  if(!currentFile)return;
  const manualInfo={
    moduleManufacturer:$("moduleManufacturer").value.trim(),
    moduleModel:$("moduleModel").value.trim(),
    vehicle:$("vehicle").value.trim(),
    year:$("year").value.trim(),
    engine:$("engine").value.trim(),
    protocol:$("protocol").value.trim()
  };
  const eepromInfo={
    enabled:$("eepromEnabled").checked,
    eepromName:$("eepromName").value.trim(),
    application:$("eepromApplication").value,
    vehicleType:$("eepromVehicleType").value.trim(),
    moduleUse:$("eepromModuleUse").value.trim(),
    fuel:$("fuel").value
  };
  currentReport=await window.dtcLab.analyzeEcuFile({filePath:currentFile.filePath,fuel:$("fuel").value,vehicleClass:$("vehicleClass").value,manualInfo,eepromInfo});
  render(currentReport);
  $("exportBtn").disabled=false;
  $("saveProjectBtn").disabled=false
};
$("saveCopyBtn").onclick=async()=>{const r=await window.dtcLab.saveWorkingCopy({filePath:currentFile.filePath,defaultName:currentFile.fileName.replace(/(\.[^.]+)?$/,"_copia_trabalho$1")});if(r)alert("Cópia salva:\\n"+r.savedPath)};
$("saveProjectBtn").onclick=async()=>{const r=await window.dtcLab.saveDtcProject({projectType:"Brasil Soluções DTC Lab",version:"3.0-offset-metadata",savedAt:new Date().toISOString(),report:currentReport});if(r)alert("Projeto salvo:\\n"+r.savedPath)};
$("exportBtn").onclick=async()=>{const r=await window.dtcLab.exportReport(currentReport);if(r)alert("Relatório salvo:\\n"+r.savedPath)};
$("quickSearch").oninput=()=>{if(!currentReport)return;const t=$("quickSearch").value.trim().toLowerCase();if(!t)return render(currentReport);const f={...currentReport,candidates:currentReport.candidates.filter(i=>[i.code,i.description,i.system,i.module,i.family].some(x=>String(x).toLowerCase().includes(t)))};f.summary={...currentReport.summary,totalCandidates:f.candidates.length};render(f)};
function render(r){$("summary").innerHTML=`<p><b>DTCs:</b> ${r.summary.totalCandidates}</p><p><b>Hits antes limpeza:</b> ${r.summary.rawHitsBeforeDedupe}</p><p><b>Offsets:</b> ${(r.offsets||[]).length}</p><p><b>Metadados:</b> ${(r.metadata||[]).length}</p><p><b>Tipo:</b> ${e(r.classification?.type)}</p><p><b>Módulo:</b> ${e(r.manualInfo?.moduleManufacturer||"-")} ${e(r.manualInfo?.moduleModel||"")}</p><p><b>EEPROM:</b> ${e(r.eepromInfo?.eepromName||"-")} ${e(r.eepromInfo?.application||"")}</p>`;renderClusters(r);renderOffsets(r);renderMeta(r);renderDrivers(r);renderOnline(r);renderDtc(r)}
function renderClusters(r){const box=$("dtcClusterInfo");if(!box)return;const items=r.dtcClusters||[];box.innerHTML=items.length?items.map(c=>`<div class="block"><b>Cluster DTC</b> ${e(c.startHex)} até ${e(c.endHex)}<br><small>${e(c.count)} hits — confiança ${e(c.confidence)} — ${e((c.codes||[]).join(", "))}</small></div>`).join(""):"Nenhum agrupamento forte de DTC."}
function renderOffsets(r){$("offsetInfo").innerHTML=(r.offsets||[]).slice(0,80).map(o=>`<div class="block"><b>${e(o.type)}</b> <code>0x${o.offset.toString(16).toUpperCase()}</code><br><small>${e(o.confidence)} — ${e(o.note)}</small></div>`).join("")||"Nenhum offset."}
function renderMeta(r){$("metadataInfo").innerHTML=(r.metadata||[]).slice(0,100).map(m=>`<div class="block"><b>${e(m.type)}</b> <code>0x${m.offset.toString(16).toUpperCase()}</code>: ${e(m.value)}</div>`).join("")||"Nenhum metadado."}
function renderDrivers(r){$("driverInfo").innerHTML=(r.drivers||[]).map(d=>`<div class="block"><b>${e(d.manufacturer)}</b> score ${e(d.score)}<br>${e((d.families||[]).join(", "))}</div>`).join("")||"Nenhum driver."}
function renderOnline(r){$("onlineInfo").innerHTML=(r.onlineQueries||[]).map(q=>`<div class="block"><b>${e(q.label)}</b><br><button class="onlineBtn" data-url="${e(q.url)}">Abrir pesquisa</button></div>`).join("");document.querySelectorAll(".onlineBtn").forEach(b=>b.onclick=()=>window.dtcLab.openOnlineQuery(b.dataset.url))}
function renderDtc(r){$("dtcTable").innerHTML=r.candidates.length?r.candidates.map(i=>`<tr><td><b>${e(i.code)}</b><br><small>${e(i.description)}</small></td><td>${e(i.family)}</td><td>${e(i.module)}</td><td>${e(i.system)}</td><td>0x${i.offset.toString(16).toUpperCase()}</td><td>${e(i.detection)}<br><small>${e(i.confidence)}</small></td><td>${e(i.risk)}</td><td><select class="dtcState" data-code="${e(i.code)}"><option value="ligado">Ligado</option><option value="desligado_lab">Desligado LAB</option><option value="revisar">Revisar</option></select></td></tr>`).join(""):`<tr><td colspan="8">Nenhum DTC candidato.</td></tr>`;document.querySelectorAll(".dtcState").forEach(s=>s.onchange=ev=>{const f=currentReport?.candidates?.find(x=>x.code===ev.target.dataset.code);if(f)f.labState=ev.target.value})}
function e(v){return String(v??"").replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll('"',"&quot;").replaceAll("'","&#039;")}
