
const fs=require("fs"),path=require("path");
function loadDrivers(){const base=path.join(__dirname,"..","drivers"),out=[];walk(base,out);return out}
function walk(dir,out){if(!fs.existsSync(dir))return;for(const it of fs.readdirSync(dir)){const f=path.join(dir,it),s=fs.statSync(f);if(s.isDirectory())walk(f,out);else if(it.endsWith(".json")){try{out.push(JSON.parse(fs.readFileSync(f,"utf8")))}catch{}}}}
function matchDrivers({fuel,vehicleClass,classification,metadata}){const meta=JSON.stringify(metadata||[]).toLowerCase();return loadDrivers().map(d=>{let score=0,txt=JSON.stringify(d).toLowerCase();if(fuel&&txt.includes(String(fuel).toLowerCase()))score+=2;if(vehicleClass&&txt.includes(String(vehicleClass).replace("linha-","").toLowerCase()))score+=1;if(classification?.type&&txt.includes(String(classification.type).toLowerCase()))score+=1;for(const k of d.keywords||[])if(meta.includes(String(k).toLowerCase()))score+=4;return{...d,score}}).sort((a,b)=>b.score-a.score).slice(0,8)}
module.exports={matchDrivers};
