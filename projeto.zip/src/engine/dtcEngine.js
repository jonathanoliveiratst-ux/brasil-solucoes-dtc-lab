
const db = require("../data/dtcDatabase.json");
const MAX_SCAN = 8 * 1024 * 1024;

function ascii(buf) {
  let out = "";
  const lim = Math.min(buf.length, MAX_SCAN);
  for (let i = 0; i < lim; i++) {
    const b = buf[i];
    out += b >= 32 && b <= 126 ? String.fromCharCode(b) : ".";
  }
  return out;
}

function findAsciiDtc(buffer) {
  const t = ascii(buffer);
  const r = /\b[PCBU][0-3][0-9A-F]{3}\b/g;
  const out = [];
  let m;
  while ((m = r.exec(t))) out.push({ code: m[0], offset: m.index, detection: "ASCII_PCODE", confidence: "alta" });
  return out;
}

function rawHexFromDtc(code) { return code.slice(1).toUpperCase(); }

function findRawHexDtc(buffer) {
  const out = [];
  const scan = buffer.length > MAX_SCAN ? buffer.subarray(0, MAX_SCAN) : buffer;
  for (const item of db) {
    const h = rawHexFromDtc(item.code);
    if (h.length !== 4) continue;
    const direct = Buffer.from(h, "hex");
    const little = Buffer.from([direct[1], direct[0]]);
    const idxDirect = scan.indexOf(direct);
    if (idxDirect !== -1) out.push({ code: item.code, offset: idxDirect, detection: "HEX_DIRETO_" + h, confidence: "média/alta" });
    const idxLittle = scan.indexOf(little);
    if (idxLittle !== -1) out.push({ code: item.code, offset: idxLittle, detection: "HEX_LITTLE_ENDIAN_" + little.toString("hex").toUpperCase(), confidence: "média" });
  }
  return out;
}

function encodeObdTwoByte(code) {
  const familyMap = { P: 0, C: 1, B: 2, U: 3 };
  const family = familyMap[code[0]];
  const digit1 = parseInt(code[1], 16);
  const last3 = parseInt(code.slice(2), 16);
  if (family === undefined || Number.isNaN(digit1) || Number.isNaN(last3)) return null;
  const value = (family << 14) | (digit1 << 12) | last3;
  return Buffer.from([(value >> 8) & 255, value & 255]);
}

function findObdEncoded(buffer) {
  const out = [];
  const scan = buffer.length > 4 * 1024 * 1024 ? buffer.subarray(0, 4 * 1024 * 1024) : buffer;
  for (const item of db) {
    const enc = encodeObdTwoByte(item.code);
    if (!enc) continue;
    const idx = scan.indexOf(enc);
    if (idx !== -1) out.push({ code: item.code, offset: idx, detection: "OBD_2_BYTES_ENCODED", confidence: "média" });
  }
  return out;
}

function enrich(c) {
  const i = db.find(x => x.code === c.code);
  return {
    ...c,
    family: i?.family || "Desconhecida",
    module: i?.module || "Desconhecido",
    system: i?.system || "Desconhecido",
    description: i?.description || "DTC candidato",
    risk: i?.risk || "revisar",
    emissions: i?.emissions ?? null,
    safety: i?.safety ?? null,
    labState: "ligado"
  };
}

function priority(detection) {
  if (detection.startsWith("ASCII")) return 5;
  if (detection.startsWith("HEX_DIRETO")) return 4;
  if (detection.startsWith("HEX_LITTLE")) return 3;
  if (detection.startsWith("OBD_2")) return 2;
  return 1;
}

function unique(arr) {
  const map = new Map();
  for (const c of arr) {
    const old = map.get(c.code);
    if (!old || priority(c.detection) > priority(old.detection) || c.offset < old.offset) map.set(c.code, c);
  }
  return [...map.values()].sort((a, b) => a.code.localeCompare(b.code));
}

function clusterCandidates(candidates) {
  const sorted = [...candidates].sort((a, b) => a.offset - b.offset);
  const clusters = [];
  let current = null;
  for (const c of sorted) {
    if (!current || c.offset - current.end > 256) {
      current = { start: c.offset, end: c.offset, count: 1, codes: [c.code] };
      clusters.push(current);
    } else {
      current.end = c.offset;
      current.count++;
      if (!current.codes.includes(c.code)) current.codes.push(c.code);
    }
  }
  return clusters.filter(c => c.count >= 2).map(c => ({
    ...c,
    startHex: "0x" + c.start.toString(16).toUpperCase(),
    endHex: "0x" + c.end.toString(16).toUpperCase(),
    confidence: c.count >= 4 ? "alta" : "média"
  }));
}

function analyzeBuffer(buffer, meta = {}) {
  const raw = [...findAsciiDtc(buffer), ...findRawHexDtc(buffer), ...findObdEncoded(buffer)];
  const candidates = unique(raw).map(enrich);
  const clusters = clusterCandidates(raw);
  return {
    app: "Brasil Soluções DTC Lab",
    fileName: meta.fileName,
    fuel: meta.fuel,
    vehicleClass: meta.vehicleClass,
    size: buffer.length,
    scanMode: "dtc_ascii_hex_endian_offset_metadata",
    summary: { totalCandidates: candidates.length, rawHitsBeforeDedupe: raw.length, dtcClusters: clusters.length },
    candidates,
    dtcClusters: clusters
  };
}
module.exports = { analyzeBuffer };
